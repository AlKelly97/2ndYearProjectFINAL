
insert into user (email,name,password,role) values ( 'admin@products.com', 'Alice Admin', 'password', 'admin' );

insert into user (email,name,password,role) values ( 'manager@products.com', 'Bob Manager', 'password', 'manager' );

insert into user (email,name,password,role) values ( 'customer@products.com', 'Charlie Customer', 'password', 'customer' );


Insert into category(cat_id,name) values(1,'RPG');
Insert into category(cat_id,name) values(2,'Sports');
Insert into category(cat_id,name) values(3,'Indie');
Insert into category(cat_id,name) values(4,'Adventure');
Insert into category(cat_id,name) values(5,'Racing');


Insert into game(id,name,age,description) values(1,'Fortnite Battle Royal', 12+);
Insert into game(id,name,age,description) values(2,'Farcry 5', 15);
Insert into game(id,name,age,description) values(3,'League of Legends', 12+);
Insert into game(id,name,age,description) values(4,'Counter Strike', 12+);
Insert into game(id,name,age,description) values(5,'Fifa 18' 3);