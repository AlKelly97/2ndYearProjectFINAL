
insert into user (email,name,password,role) values ( 'admin@game.com', 'Alice Admin', 'password', 'admin' );

insert into user (email,name,password,role) values ( 'manager@products.com', 'Bob Manager', 'password', 'manager' );

insert into user (email,name,password,role) values ( 'customer@products.com', 'Charlie Customer', 'password', 'customer' );


Insert into category(cat_id,name) values(1,'RPG');
Insert into category(cat_id,name) values(2,'Sports');
Insert into category(cat_id,name) values(3,'Indie');
Insert into category(cat_id,name) values(4,'Adventure');
Insert into category(cat_id,name) values(5,'Racing');


Insert into game(id,name,age,description,cat_id) values(1,'Fortnite Battle Royal', 12+, 'Fortnite is a co-op sandbox survival game developed by Epic Games and People Can Fly and published by Epic Games',4 );
Insert into game(id,name,age,description,cat_id) values(2,'Farcry 5', 15,'Far Cry 5 is an action-adventure first-person shooter game developed by Ubisoft Montreal and Ubisoft Toronto and published by Ubisoft for Microsoft Windows, PlayStation 4 and Xbox One.',4),;
Insert into game(id,name,age,description,cat_id) values(3,'League of Legends', 12+);
Insert into game(id,name,age,description,cat_id) values(4,'Counter Strike', 12+);
Insert into game(id,name,age,description,cat_id) values(5,'Fifa 18' 3);